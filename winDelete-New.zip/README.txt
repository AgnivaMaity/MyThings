This is a malicious file
It can cause permanent damage to your pc
Run in VM only :)
-----------------------------------------
Made by = Agniva
youtube = https://www.youtube.com/channel/UCTJDIIyJ2r_834PHEyuH6ug
(subscribe is highly appreciated :) )

Programming languaged used = C | C++ | Batch
------------------------------------------